from __future__ import annotations
from collections import OrderedDict
import numpy as np
from sklearn.ensemble import GradientBoostingClassifier, ExtraTreesClassifier, RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import RidgeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import LinearSVC
from xgboost import XGBClassifier


def build_baseline_models(config: dict):
    rs = config["project"]["random_state"]
    b = config["baseline_models"]
    return OrderedDict([
        ("Gradient Boosting", GradientBoostingClassifier(random_state=rs)),
        ("Decision Tree", DecisionTreeClassifier(random_state=rs)),
        ("Extra Trees", ExtraTreesClassifier(n_estimators=b["extra_trees"]["n_estimators"], n_jobs=b["extra_trees"]["n_jobs"], random_state=rs)),
        ("Random Forest", RandomForestClassifier(n_estimators=b["random_forest"]["n_estimators"], n_jobs=b["random_forest"]["n_jobs"], random_state=rs)),
        ("k-Nearest Neighbours", KNeighborsClassifier(n_neighbors=b["knn"]["n_neighbors"])),
        ("MLP Classifier", MLPClassifier(hidden_layer_sizes=tuple(b["mlp"]["hidden_layer_sizes"]), max_iter=b["mlp"]["max_iter"], random_state=rs)),
        ("Ridge Classifier", RidgeClassifier(alpha=b["ridge"]["alpha"])),
        ("Naive Bayes", GaussianNB()),
        ("Linear SVM", LinearSVC(C=b["linear_svm"]["C"], random_state=rs)),
    ])


def score_values(model, X):
    """Continuous attack score for AUC and stacking meta-features."""
    if hasattr(model, "predict_proba"):
        return model.predict_proba(X)[:, 1]
    if hasattr(model, "decision_function"):
        return np.asarray(model.decision_function(X), dtype=float)
    return np.asarray(model.predict(X), dtype=float)


def make_xgb(params: dict, random_state=123):
    return XGBClassifier(
        **params,
        objective="binary:logistic",
        eval_metric="logloss",
        random_state=random_state,
        n_jobs=-1,
    )
