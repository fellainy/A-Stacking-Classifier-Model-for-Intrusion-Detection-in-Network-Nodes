from __future__ import annotations
import numpy as np
from scipy.stats import binom
from sklearn.ensemble import RandomForestClassifier


class ShadowBorutaSelector:
    """Boruta-compatible selector using randomized shadow features.

    Each iteration permutes every real feature to create a shadow copy, fits a
    RandomForestClassifier on [real + shadow], and records a hit when a real
    feature importance exceeds the maximum shadow importance. With five
    iterations, five hits gives one-sided Binomial(5, .5) p=0.03125.

    This is the transparent shadow-feature implementation used for the revised
    reproducibility workflow when BorutaPy is unavailable. It must be fit only
    on training data (or a fold-training subset).
    """

    def __init__(self, n_iterations=5, n_estimators=100, random_state=123,
                 class_weight="balanced", n_jobs=-1):
        self.n_iterations = int(n_iterations)
        self.n_estimators = int(n_estimators)
        self.random_state = int(random_state)
        self.class_weight = class_weight
        self.n_jobs = n_jobs

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y)
        rng = np.random.default_rng(self.random_state)
        p = X.shape[1]
        hits = np.zeros(p, dtype=int)
        mean_importance = np.zeros(p, dtype=float)

        for i in range(self.n_iterations):
            shadow = np.empty_like(X)
            for j in range(p):
                shadow[:, j] = rng.permutation(X[:, j])
            X_aug = np.hstack([X, shadow])
            rf = RandomForestClassifier(
                n_estimators=self.n_estimators,
                random_state=self.random_state + i,
                class_weight=self.class_weight,
                n_jobs=self.n_jobs,
            )
            rf.fit(X_aug, y)
            imp = rf.feature_importances_
            real_imp, shadow_imp = imp[:p], imp[p:]
            threshold = float(np.max(shadow_imp))
            hits += real_imp > threshold
            mean_importance += real_imp

        mean_importance /= self.n_iterations
        pvals = binom.sf(hits - 1, self.n_iterations, 0.5)
        # Revised experiment used a strict all-iteration confirmation rule.
        support = hits == self.n_iterations
        if not np.any(support):
            # Defensive fallback for unusually noisy environments: retain at
            # least features with one-sided p<.05, then the best feature.
            support = pvals < 0.05
        if not np.any(support):
            support[np.argmax(mean_importance)] = True

        self.hits_ = hits
        self.p_values_ = pvals
        self.importances_ = mean_importance
        self.support_ = support
        return self

    def transform(self, X):
        if not hasattr(self, "support_"):
            raise RuntimeError("fit must be called before transform")
        return np.asarray(X)[:, self.support_]

    def fit_transform(self, X, y):
        return self.fit(X, y).transform(X)
