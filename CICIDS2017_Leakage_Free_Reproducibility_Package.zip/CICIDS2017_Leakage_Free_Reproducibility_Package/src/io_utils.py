from __future__ import annotations
import json
from pathlib import Path
import yaml
import pandas as pd
import numpy as np


def load_config(path: str | Path = "config.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def ensure_dirs(root: str | Path = ".") -> None:
    root = Path(root)
    for p in ["data/splits", "outputs/tables", "outputs/figures", "outputs/logs", "outputs/models"]:
        (root / p).mkdir(parents=True, exist_ok=True)


def clean_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c).strip() for c in out.columns]
    return out


def load_dataset(config: dict, root: str | Path = ".") -> pd.DataFrame:
    root = Path(root)
    path = root / "data" / "raw" / config["project"]["dataset_file"]
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}\n"
            "Place Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv in data/raw/."
        )
    df = pd.read_csv(path, low_memory=False)
    return clean_columns(df)


def make_binary_target(df: pd.DataFrame, config: dict):
    target = config["project"]["target_column"]
    benign = config["project"]["benign_label"]
    labels = df[target].astype(str).str.strip()
    y = (labels != benign).astype(int)
    X = df.drop(columns=[target]).copy()
    # Coerce CICFlowMeter columns to numeric; invalid text becomes NaN and is handled fold-wise.
    for c in X.columns:
        X[c] = pd.to_numeric(X[c], errors="coerce")
    X = X.replace([np.inf, -np.inf], np.nan)
    return X, y, labels


def save_json(obj, path: str | Path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, default=float)
