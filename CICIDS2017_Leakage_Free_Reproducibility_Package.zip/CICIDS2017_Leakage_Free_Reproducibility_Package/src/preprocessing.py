from __future__ import annotations
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler


def undersample_training(X, y, benign_fraction=0.70, random_state=123):
    """Keep every attack sample and randomly sample benign records to ~70:30."""
    X = np.asarray(X)
    y = np.asarray(y)
    rng = np.random.default_rng(random_state)
    attack_idx = np.flatnonzero(y == 1)
    benign_idx = np.flatnonzero(y == 0)
    n_attack = len(attack_idx)
    n_benign_target = int(round(n_attack * benign_fraction / (1.0 - benign_fraction)))
    n_benign_target = min(n_benign_target, len(benign_idx))
    selected_benign = rng.choice(benign_idx, size=n_benign_target, replace=False)
    idx = np.concatenate([selected_benign, attack_idx])
    rng.shuffle(idx)
    return X[idx], y[idx], idx


def fit_fold_preprocessor(X_train):
    imputer = SimpleImputer(strategy="median")
    X_imp = imputer.fit_transform(X_train)
    return imputer, X_imp


def fit_scaler(X_train_selected):
    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X_train_selected)
    return scaler, X_scaled
